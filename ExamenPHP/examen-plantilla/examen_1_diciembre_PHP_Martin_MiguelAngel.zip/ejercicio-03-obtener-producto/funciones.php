<?php
$datos = [["codigo" => "1020TV", "nombre" => "Televisor", "precio" => 750, "stock" => 30, "marca" => "LG", "ultima" => "13/11/2020"], 
["codigo" => "1518CM", "nombre" => "Cámara", "precio" => 325, "stock" => 22, "marca" => "Nikon", "ultima" => "10/10/2020"],
["codigo" => "2050CN", "nombre" => "Consola", "precio" => 299, "stock" => 15, "marca" => "Nintendo", "ultima" => "23/09/2020"],
["codigo" => "3065PT", "nombre" => "Portatil", "precio" => 595, "stock" => 7, "marca" => "Lenovo", "ultima" => "31/08/2020"],
["codigo" => "3560AA", "nombre" => "Aire Acondicionado", "precio" => 420, "stock" => 18, "marca" => "Daikin", "ultima" => "09/09/2020"],
["codigo" => "4090RC", "nombre" => "Robot de Cocina", "precio" => 380, "stock" => 35, "marca" => "Moulinex", "ultima" => "26/10/2020"],
["codigo" => "5020MC", "nombre" => "Microondas", "precio" => 175, "stock" => 8, "marca" => "Candy", "ultima" => "19/07/2020"],
["codigo" => "5575RI", "nombre" => "Ratón inalámbtico", "precio" => 15, "stock" => 35, "marca" => "Logitec", "ultima" => "24/10/2020"],
["codigo" => "6070AV", "nombre" => "Altavoces", "precio" => 30, "stock" => 4, "marca" => "Sony", "ultima" => "01/10/2020"],
["codigo" => "7025MV", "nombre" => "Móvil", "precio" => 500, "stock" => 10, "marca" => "Samsung", "ultima" => "30/11/2020"]
]
