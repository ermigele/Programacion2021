<?php
include("funciones.php");
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Obtener productos
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Obtener productos</h1>

  <label>Seleccione Productos</label><br />
  <select name="productos" multiple>
    <option name="televisor">Televisor</option>
    <option name="camara">Cámara</option>
    <option name="consola">Consola</option>
    <option name="portatil">Portátil</option>
  </select> <br /> <br />

  <label>Selecciona una información adicional: </label> <br /> <br />
  <input>
</body>

</html>